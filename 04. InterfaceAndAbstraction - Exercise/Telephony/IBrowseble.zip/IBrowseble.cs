﻿namespace Telephony
{
    public interface IBrowseble
    {
        void Browse(string url);
    }
}
