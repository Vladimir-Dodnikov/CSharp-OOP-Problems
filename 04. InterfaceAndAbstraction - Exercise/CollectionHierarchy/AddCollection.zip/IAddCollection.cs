﻿namespace CollectionHierarchy
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
