﻿namespace BorderControl
{
    interface IIdentitiable
    {
        string ID { get; }
    }
}
