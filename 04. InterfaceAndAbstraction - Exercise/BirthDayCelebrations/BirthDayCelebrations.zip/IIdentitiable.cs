﻿namespace BirthDayCelebrations
{
    interface IIdentitiable
    {
        string Id { get; }
    }
}
