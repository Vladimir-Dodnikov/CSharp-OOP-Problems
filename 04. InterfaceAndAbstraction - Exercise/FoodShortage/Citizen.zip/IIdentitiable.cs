﻿namespace FoodShortage
{
    interface IIdentitiable
    {
        string Id { get; }
    }
}
