﻿using FootballTeamGenerator.Core;

namespace PizzaCalories
{
    class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
