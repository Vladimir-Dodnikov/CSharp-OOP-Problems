﻿namespace Restaurant.Beverages
{
    public class Tea : Beverage
    {
        public Tea(string name, decimal price, double mililiters)
            : base(name, price, mililiters)
        {

        }
    }
}
