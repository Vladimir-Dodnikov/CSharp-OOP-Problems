﻿namespace PlayersAndMonsters
{
    public class SoulMaster : DarkWizard
    {
        public SoulMaster(string userName, int level) : base(userName, level)
        {
        }
    }
}
