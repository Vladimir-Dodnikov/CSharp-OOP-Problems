﻿namespace PlayersAndMonsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string userName, int level) : base(userName, level)
        {
        }
    }
}
