﻿namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string userName, int level) : base(userName, level)
        {
        }
    }
}
