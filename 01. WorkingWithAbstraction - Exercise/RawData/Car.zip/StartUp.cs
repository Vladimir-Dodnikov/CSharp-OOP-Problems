﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData
{
    class StartUp
    {
        static void Main(string[] args)
        {
            RawData rawData = new RawData();
            rawData.Runner();
        }
    }
}
