﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarSalesman
{
    class StartUp
    {
        static void Main()
        {
            Runner.Run();
        }
    }
}
